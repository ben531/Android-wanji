#!/sbin/sh
# Shell Script EDIFY Replacement

if [ $(initialize_app_set "Core") = "1" ]; then
  install_the_package "Core" "ExtraFiles"
  set_progress 0.15
  install_the_package "Core" "GooglePlayStore"
  set_progress 0.3
  install_the_package "Core" "GoogleServicesFramework"
  set_progress 0.45
  install_the_package "Core" "GoogleContactsSyncAdapter"
  set_progress 0.6
  install_the_package "Core" "GoogleCalendarSyncAdapter"
  set_progress 0.75
  install_the_package "Core" "GmsCore"
  set_progress 0.9
else
  ui_print "x Skipping Core"
fi

set_progress 1.00

exit_install

